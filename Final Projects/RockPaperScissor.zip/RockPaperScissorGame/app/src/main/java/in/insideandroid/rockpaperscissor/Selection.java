package in.insideandroid.rockpaperscissor;

public enum Selection {
    ROCK, PAPER, SCISSOR
}
