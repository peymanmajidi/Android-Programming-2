package in.insideandroid.rockpaperscissor;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;
//Group project of Reza Asadi Vahdat and Erfan Gholami and Mohammad Reza Ghanifard

public class MainActivity extends AppCompatActivity implements View.OnClickListener {

    Button button_rock, button_paper, button_scissor;
    String personName;
    TextView plyername, plyerEmtyaz;
    String userS,CPU_S;
    int emtyaz , emtyazout;

    public void btn_person_onclick(View view) {
        android.app.AlertDialog.Builder builder = new android.app.AlertDialog.Builder(this);
        builder.setTitle("برای شروع نام خود را وارد کنید");

        final EditText txtnwme = new EditText(this);

        txtnwme.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(txtnwme);

        builder.setPositiveButton("تایید", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                personName = txtnwme.getText().toString();
                Toast.makeText(getApplicationContext(),txtnwme.getText().toString() +" "+"خب حالا میونی شروع کنی ",
                        Toast.LENGTH_LONG).show();
                plyername.setText(txtnwme.getText().toString());
                SH_pr.Updat(getApplicationContext(),personName);

            }
        });
        builder.setNegativeButton("لغو", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.cancel();

            }
        });
        builder.show();
    }


    //default value assigned to user_selection
    private static Selection user_selection = Selection.SCISSOR;
    private static Selection cpu_selection = Selection.ROCK;

    private static boolean user_winner = true;
    private static boolean match_draw = false;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        button_rock = findViewById(R.id.button_rock);
        button_paper = findViewById(R.id.button_paper);
        button_scissor = findViewById(R.id.button_scissor);

        button_rock.setOnClickListener(this);
        button_paper.setOnClickListener(this);
        button_scissor.setOnClickListener(this);

        plyername=findViewById(R.id.lblNme);
        plyerEmtyaz=findViewById(R.id.lblemtyaz);


        //SH_pr Read
        String name = SH_pr.Read(getApplicationContext());
        if (name!=SH_pr.bdonnam)
        {
            plyername.setText(name);
        }
        int useremtyaz = SH_pr.Reada(getApplicationContext());
        if (useremtyaz !=SH_pr.bdonvrodi)
        {
            plyerEmtyaz.setText("امتیاز شما =" + useremtyaz);
        }
        emtyazout = useremtyaz;
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()){

            case R.id.button_rock:
                user_selection = Selection.ROCK;
                userS ="سنگ";
                break;

            case R.id.button_paper:
                user_selection = Selection.PAPER;
                userS ="کاغذ";
                break;

            case R.id.button_scissor:
                user_selection = Selection.SCISSOR;
                userS ="قیچی";
                break;
        }

        proceed();
    }

    private void proceed() {
        //get random cpu selection
        cpu_selection = getRandomCPUSelection();

        //get winner based on cpu_selection and user_selection
        checkWinner();

        //print result based on result
        showWinner();
    }

    //function return random value below 3
    private Selection getRandomCPUSelection() {
        int random = new Random().nextInt(3);

        switch (random) {
            case 0: return Selection.ROCK;
            case 1: return Selection.PAPER;
            case 2: return Selection.SCISSOR;
        }
        return Selection.ROCK;
    }

    private void checkWinner() {

        //rock wins from scissor, loose from paper
        if(user_selection == Selection.ROCK){
            if(cpu_selection == Selection.PAPER){
                CPU_S = "کاغذ";
                user_winner = false;
                return;
            }
            else if(cpu_selection == Selection.SCISSOR){
                CPU_S = "قیچی";
                user_winner = true;
                return;
            }
            else if(cpu_selection == Selection.ROCK){
                CPU_S = "سنگ";
                match_draw = true;
                return;
            }
        }

        //paper wins from rock, loose from scissor
        if(user_selection == Selection.PAPER){
            if(cpu_selection == Selection.SCISSOR){
                CPU_S = "قیچی";
                user_winner = false;
                return;
            }
            else if(cpu_selection == Selection.ROCK){
                CPU_S = "سنگ";
                user_winner = true;
                return;
            }
            else if(cpu_selection == Selection.PAPER){
                CPU_S = "کاغذ";
                match_draw = true;
                return;
            }
        }

        //scissor wins from paper, loose from rock
        if(user_selection == Selection.SCISSOR){
            if(cpu_selection == Selection.ROCK){
                CPU_S = "سنگ";
                user_winner = false;
                return;
            }
            else if(cpu_selection == Selection.PAPER){
                CPU_S = "کاغذ";
                user_winner = true;
                return;
            }
            else if(cpu_selection == Selection.SCISSOR){
                CPU_S = "قیچی";
                match_draw = true;
                return;
            }
        }

        Log.e("انتخاب سیستم :",CPU_S);
        Log.e("انتخاب کاربر :", userS);
    }

    //show dialog to show result
    private void showWinner() {

        String line1 = "انتخاب کاربر : "+userS;
        String line2 = "انتخاب سیستم : "+CPU_S;
        String result ="نتیجه : "+getResultString();

        String message = line1 + "\n" + line2 + "\n"+ result;

        new AlertDialog.Builder(MainActivity.this)
                .setTitle("Result")
                .setMessage(message)
                .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int which) {
                        // close dialog
                        dialog.dismiss();
                    }
                })
                .setOnDismissListener(new DialogInterface.OnDismissListener() {
                    @Override
                    public void onDismiss(DialogInterface dialog) {
                        //reset values when dialog is dismissed
                        resetValues();
                    }
                })
                .show();
    }

    //values reset for next game
    private void resetValues() {
        user_selection = Selection.SCISSOR;
        cpu_selection = Selection.ROCK;

        user_winner = true;
        match_draw = false;
        Log.e(MainActivity.class.getName(), " مقادیر با موفقیت تنظیم مجدد شدند");
    }

    //function return result string based on user_selection and cpu_selection
    private String getResultString() {

        String result;
        if(match_draw == true){
            result = "انتخاب یکسان دوباره انتخاب کنید";
        }
        else {
            if (user_winner){
                result = "شما برنده شدید!";
                emtyazout = emtyazout + 10;
                plyerEmtyaz.setText("امتیاز ="+emtyazout);
            }else {
                result = "شما باختید!!!";
                plyerEmtyaz.setText("امتیاز ="+emtyazout);
            }
        }
        SH_pr.Upda(getApplicationContext(),emtyazout);

        return result;
    }

    public void btnreset_ovclich(View view) {
        emtyazout=0;
        plyerEmtyaz.setText("امتیاز ="+emtyazout);

    }
}
