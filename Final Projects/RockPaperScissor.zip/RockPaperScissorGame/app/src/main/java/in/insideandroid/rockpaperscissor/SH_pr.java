package in.insideandroid.rockpaperscissor;

import android.content.Context;
import android.content.SharedPreferences;

public class SH_pr {

    public static String APP="Myappsetting";
    public static String username="username";
    public static String bdonnam="null";
    public static int emtyaz=0;
    public static int bdonvrodi=0;

    public static String Read (Context context)
    {
        SharedPreferences prefernces = context.getSharedPreferences(APP , Context.MODE_PRIVATE);
        return prefernces.getString(username,bdonnam);
    }

    public static void Updat (Context context , String name)
    {
        SharedPreferences.Editor editor = context.getSharedPreferences(APP , Context.MODE_PRIVATE).edit();
        editor.putString(username,name);
        editor.apply();
    }

    public static int Reada (Context context){
        SharedPreferences preferences = context.getSharedPreferences(APP, Context.MODE_PRIVATE);
        return preferences.getInt(String.valueOf(emtyaz), bdonvrodi);
    }

    public static void Upda(Context context, int emtyazout) {
        SharedPreferences.Editor editor = context.getSharedPreferences(APP, Context.MODE_PRIVATE).edit();
        editor.putInt(String.valueOf(emtyaz), emtyazout);
        editor.apply();
    }
}
