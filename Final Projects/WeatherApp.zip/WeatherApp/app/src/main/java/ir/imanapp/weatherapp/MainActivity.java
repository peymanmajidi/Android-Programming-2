package ir.imanapp.weatherapp;

import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.loopj.android.http.AsyncHttpClient;
import com.loopj.android.http.JsonHttpResponseHandler;
import com.loopj.android.http.RequestParams;

import org.json.JSONObject;

import cz.msebera.android.httpclient.Header;

public class MainActivity extends AppCompatActivity {



    final String APP_ID = "82419ad5564a6edc198530e149996841";
    final String WEATHER_URL = "https://api.openweathermap.org/data/2.5/weather";

    TextView NameofCity, weatherState, Temperature;
    ImageView mweatherIcon;

    RelativeLayout mCityFinder;

    public static String translate_farsi = "ایمان";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weatherState = findViewById(R.id.weatherCondition);
        Temperature = findViewById(R.id.temperature);
        mweatherIcon = findViewById(R.id.weatherIcon);
        mCityFinder = findViewById(R.id.cityFinder);
        NameofCity = findViewById(R.id.cityName);


        mCityFinder.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(ir.imanapp.weatherapp.MainActivity.this, cityFinder.class);
                startActivity(intent);
            }
        });

    }


    @Override
    protected void onResume() {
        super.onResume();
        Intent mIntent=getIntent();
        String city= mIntent.getStringExtra("City");
        if(city!=null)
        {
            getWeatherForNewCity(city);
        }
    }


    private void getWeatherForNewCity(String city)
    {
        RequestParams params=new RequestParams();
        params.put("q",city);
        params.put("appid",APP_ID);
        letsdoSomeNetworking(params);
    }



    private  void letsdoSomeNetworking(RequestParams params)
    {
        AsyncHttpClient client = new AsyncHttpClient();
        client.get(WEATHER_URL,params,new JsonHttpResponseHandler()
        {
            @Override
            public void onSuccess(int statusCode, Header[] headers, JSONObject response) {


                weatherData weatherD=weatherData.fromJson(response);
                updateUI(weatherD);

            }


            @Override
            public void onFailure(int statusCode, Header[] headers, Throwable throwable, JSONObject errorResponse) {
                //super.onFailure(statusCode, headers, throwable, errorResponse);
            }
        });



    }


    private  void updateUI(weatherData weather){


        Temperature.setText(weather.getmTemperature());
        NameofCity.setText(weather.getMcity());
        int resourceID=getResources().getIdentifier(weather.getMicon(),"drawable",getPackageName());
        mweatherIcon.setImageResource(resourceID);

        switch (weather.getmWeatherType())
        {
            case "Thunderstorm":
                translate_farsi = "رعد و برق";
                break;
            case "Rain":
                translate_farsi = "باران";
                break;
            case "Drizzle":
                translate_farsi = "باران ریز و نمناک";
                break;
            case "Snow":
                translate_farsi = "برف";
                break;
            case "Mist":
                translate_farsi = "غبار";
                break;
            case "Smoke":
                translate_farsi = "دود";
                break;
            case "Haze":
                translate_farsi = "مه";
                break;
            case "Dust":
                translate_farsi = "گرد و خاک";
                break;
            case "Fog":
                translate_farsi = "مه";
                break;
            case "Sand":
                translate_farsi = "شن";
                break;
            case "Ash":
                translate_farsi = "خاکستر";
                break;
            case "Squall":
                translate_farsi = "توفان";
                break;
            case "Tornado":
                translate_farsi = "گردباد";
                break;
            case "Clear":
                translate_farsi = "تمیز";
                break;
            case "Clouds":
                translate_farsi = "ابری";
                break;
            default:
                translate_farsi = "وضعیت هوا";
        }

        weatherState.setText(translate_farsi);
    }

}