package ir.imanapp.weatherapp;

import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class cityFinder extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_city_finder);
        final EditText editText=findViewById(R.id.searchCity);
        ImageView backButton=findViewById(R.id.backButton);


        //---------------------------------------------database iman------------------------------------------------------
        String DATABASE_NAME = "iman.b.db";
        String TABLE_NAME = "MY_TABLE";
        try{
            SQLiteDatabase mydb = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE,null);
            Cursor allrows  = mydb.rawQuery("SELECT * FROM "+  TABLE_NAME, null);
            if(allrows.moveToLast()){
                do{
                    String CITY = allrows.getString(1);

                    editText.setText(CITY);
                }
                while(allrows.moveToNext());
            }
            mydb.close();
        }catch(Exception e){
            //Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
        }
        //---------------------------------------------database iman------------------------------------------------------


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });



        editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                String newCity= editText.getText().toString();
                Intent intent=new Intent(ir.imanapp.weatherapp.cityFinder.this,MainActivity.class);
                intent.putExtra("City",newCity);
                startActivity(intent);

                //---------------------------------------------database iman------------------------------------------------------
                String DATABASE_NAME = "iman.b.db";
                String TABLE_NAME = "MY_TABLE";
                try{
                    SQLiteDatabase mydb = openOrCreateDatabase(DATABASE_NAME, Context.MODE_PRIVATE,null);
                    mydb.execSQL("CREATE TABLE IF  NOT EXISTS "+ TABLE_NAME +" (ID INTEGER PRIMARY KEY, CITY TEXT);");
                    mydb.execSQL("INSERT INTO " + TABLE_NAME + " (CITY) VALUES ('"+newCity+"')");
                    Toast.makeText(ir.imanapp.weatherapp.cityFinder.this,"نام شهر ذخیره شد.", Toast.LENGTH_SHORT).show();
                    mydb.close();
                }catch(Exception e){
                 //   Toast.makeText(getApplicationContext(), "Error", Toast.LENGTH_LONG).show();
                }
                //---------------------------------------------database iman------------------------------------------------------

                return false;
            }
        });





    }
}