package com.example.numner;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Random;

public class MainActivity extends AppCompatActivity {
    // motqayer ha
    String fullname;

    EditText numberEditText;

    TextView plyername;
    TextView lblout;
    TextView lblscore;

    int randomNumber;
    int guess = 0;
    int scor , scor_v2;
    int number;


    //alert dialog
    public void btnhow_Click(View view) {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("برای شروع نام خود را وارد کنید");

        final EditText txtnwme = new EditText(this);

        txtnwme.setInputType(InputType.TYPE_CLASS_TEXT);
        builder.setView(txtnwme);

        builder.setPositiveButton("تایید", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                fullname = txtnwme.getText().toString();
                Toast.makeText(getApplicationContext(),txtnwme.getText().toString() +" "+"خوش امدید",
                        Toast.LENGTH_LONG).show();
                plyername.setText("نام کاربری شما = " + txtnwme.getText().toString());
                setting.Updateprefernces(getApplicationContext(),fullname);

            }
        });
        builder.setNegativeButton("لغو", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.cancel();

            }
        });
        builder.show();
    }

    //asl kari!!!
    public void displayResult(String result) {
        Toast.makeText(MainActivity.this, result, Toast.LENGTH_SHORT).show();

    }

    public void btnguess_onClick(View view) {
        numberEditText = (EditText) findViewById(R.id.numberEditText);
        number = randomNumber;
        int guessNumber = Integer.parseInt(numberEditText.getText().toString());

            if ((guessNumber != 0) && (guessNumber <= 20)) {
                if ((guessNumber != randomNumber) && (guess == 5)) {

                    lblout.setText("شما تعداد حدس مجازتان را زدید و نتوانستید درست حدس بزنید دوباره شروع کن به حدس زدن");
                    Random rand = new Random();
                    randomNumber = rand.nextInt(20) + 1;
                    guess = 0;
                    numberEditText.setText("0");

                } else if (guessNumber > randomNumber) {
                    displayResult("برو‍‍ پایین تر ");
                    guess++;
                    lblout.setText(("برو پایین تر حدس شما = " + guessNumber + " تعداد حدس های زده شده =" + guess).toString());
                    numberEditText.setText("0");

                } else if (guessNumber < randomNumber) {
                    displayResult("برو بالا تر");
                    guess++;
                    lblout.setText(("برو بالا تر حدس شما = " + guessNumber + " تعداد حدس های زده شده =" + guess).toString());
                    numberEditText.setText("0");

                } else {
                    // محاسبه امتیاز
                    if (guess == 1) {

                        scor_v2 = 50;

                    } else if (guess == 2) {

                        scor_v2 = 40;

                    } else if (guess == 3) {

                        scor_v2 = 30;

                    } else if (guess == 4) {

                        scor_v2 = 20;

                    } else {

                    scor_v2 = 10;

                    }

                    displayResult("حدس درست");
                    lblout.setText((" درست حدس زدی " + number + " تعداد حدس های شما = " + guess + "دوباره شروع کن!!!").toString());
                    numberEditText.setText("0");

                    scor = scor + scor_v2;
                    lblscore.setText(("امتیاز شما =  " + scor).toString());
                    setting.Updascor(getApplicationContext(),scor);
                }
            } else {
                lblout.setText("یک عدد بین 1 تا 20 وارد کنید !!!");
            }

    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Random rand = new Random();
        randomNumber = rand.nextInt(20) + 1;

        lblout = findViewById(R.id.lbladad);
        lblscore = findViewById(R.id.lblscor);
        plyername=findViewById(R.id.lblUserNme);



        //setting Read
        String name = setting.Readprefernces(getApplicationContext());
        if (name!=setting.NO_NAME)
        {
            plyername.setText("نام کاربری شما = " + name);
        }

        int userscor = setting.Readscore(getApplicationContext());
        if (userscor !=setting.NO_scor)
        {
            lblscore.setText("امتیاز شما =" + userscor);
        }
    }

    public void btnnew_onClick(View view) {
        lblout.setText("شروع کن به حدس زدن");
        guess = 0;
        Random rand = new Random();
        randomNumber = rand.nextInt(20) + 1;
    }
}