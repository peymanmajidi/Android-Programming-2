package com.example.numner;

import android.content.Context;
import android.content.SharedPreferences;

public class setting {
    public static String TITEL="Myappsetting";
    public static String FULLNAME="username";
    public static String NO_NAME="null";

    public static int score=0;
    public static int NO_scor=0;

    public static String Readprefernces (Context context)
    {
        SharedPreferences prefernces = context.getSharedPreferences(TITEL , Context.MODE_PRIVATE);
        return prefernces.getString(FULLNAME,NO_NAME);
    }

    public static void Updateprefernces (Context context , String name)
    {
        SharedPreferences.Editor editor = context.getSharedPreferences(TITEL , Context.MODE_PRIVATE).edit();
        editor.putString(FULLNAME,name);
        editor.apply();
    }



    // write on SharedPreferences
    public static int Readscore (Context context){
        SharedPreferences preferences = context.getSharedPreferences(TITEL, Context.MODE_PRIVATE);
        return preferences.getInt(String.valueOf(score), NO_scor);
    }

    public static void Updascor(Context context, int scor) {
        // read
        SharedPreferences.Editor editor = context.getSharedPreferences(TITEL, Context.MODE_PRIVATE).edit();
        editor.putInt(String.valueOf(score), scor);
        editor.apply();
    }


}
